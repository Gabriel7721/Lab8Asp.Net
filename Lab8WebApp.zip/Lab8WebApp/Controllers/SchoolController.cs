using Lab8WebApp.Models;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;

namespace Lab8WebApp.Controllers;

public class SchoolController : Controller
{
    private readonly string url = "http://localhost:5033/api/School/";
    private readonly HttpClient httpClient = new HttpClient();
    public IActionResult Index(int studentId)
    {
        var model = JsonConvert.DeserializeObject<IEnumerable<Mark>>(httpClient.GetStringAsync(url + studentId).Result);
        if (studentId != null)
        {
            return View(model);
        }
        else
        {
            return View();
        }
    }
    
    [HttpGet]
    public IActionResult Create()
    {
        return View();
    }
    [HttpPost]
    public IActionResult Create(Mark newSubject)
    {
        try
        {
            var model = httpClient.PostAsJsonAsync(url, newSubject).Result;
            if(model.IsSuccessStatusCode)
            {
                return RedirectToAction("Index", "School");
            }
            else
            {
                ModelState.AddModelError(string.Empty, "Fail");
            }
        }
        catch(Exception ex)
        {
            ModelState.AddModelError(string.Empty, ex.Message);
        }
        return View();
    }
    
    [HttpGet]
    public IActionResult Edit(int studentId,string subject)
    {
        var model = JsonConvert.DeserializeObject<Mark>(httpClient.GetStringAsync(url + studentId +"/" + subject).Result);
        return View(model);
    }
    [HttpPost]
    public IActionResult Edit(Mark editMark)
    {
        try
        {
            var model = httpClient.PutAsJsonAsync(url, editMark).Result;
            if (model.IsSuccessStatusCode)
            {
                return RedirectToAction("Index", "School");
            }
            else
            {
                ModelState.AddModelError(string.Empty, "Fail");
            }
        }
        catch (Exception ex)
        {
            ModelState.AddModelError(string.Empty, ex.Message);
        }
        return View();
    }

    public IActionResult Delete(int studentId, string subject)
    {
        var model = httpClient.DeleteAsync(url+ studentId + "/" + subject).Result;
        return RedirectToAction("Index", "School");
    }
}