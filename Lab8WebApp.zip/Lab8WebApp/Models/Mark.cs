﻿using System;
using System.Collections.Generic;

namespace Lab8WebApp.Models;

public partial class Mark
{
    public int StudentId { get; set; }

    public string Subject { get; set; } = null!;

    public decimal? Mark1 { get; set; }
}
