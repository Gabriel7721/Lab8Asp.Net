﻿using System;
using System.Collections.Generic;

namespace Lab8WebApp.Models;

public partial class Student
{
    public int StudentId { get; set; }

    public string? Name { get; set; }
}
